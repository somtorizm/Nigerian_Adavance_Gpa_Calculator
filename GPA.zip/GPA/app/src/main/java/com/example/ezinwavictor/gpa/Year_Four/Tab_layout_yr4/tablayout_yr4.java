package com.example.ezinwavictor.gpa.Year_Four.Tab_layout_yr4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.ezinwavictor.gpa.R;

public class tablayout_yr4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tablayout_yr4);
    }
}
