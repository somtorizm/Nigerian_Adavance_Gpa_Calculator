package com.example.ezinwavictor.gpa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.ezinwavictor.gpa.Year_One.Tablayout_Year_One.tablayoutyr1;
import com.example.ezinwavictor.gpa.Year_One.firstsemesteryr1;
import com.example.ezinwavictor.gpa.Year_One.secondsemesteryr1;
import com.example.ezinwavictor.gpa.Year_Two.TabLayout_yr2.tablayout_year_2;
import com.example.ezinwavictor.gpa.Year_Two.first_semester_yr2;
import com.example.ezinwavictor.gpa.Year_Two.second_semester_yr2;

import java.text.DecimalFormat;
import java.util.zip.Inflater;


public class select_level extends AppCompatActivity {

    Spinner spinner_level;
    android.support.v7.widget.Toolbar toolbar1;
    String[] level_yrs = {"Select Year", "Year One", "Year Two", "Year Three", "Year Four", "Year Five", "Year Six"};
    TextView level_txt_view, level_grade_view, total_yr_credit;
    Button show_the_level;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.select_level_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_level);
        toolbar1 = findViewById(R.id.toolbar_select_level);
        setSupportActionBar(toolbar1);
        spinner_level = findViewById(R.id.spinner_year_selection);
        ArrayAdapter<String> level_adapter = new ArrayAdapter<>(this, R.layout.custom_spinner_item, level_yrs);
        level_adapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spinner_level.setAdapter(level_adapter);
        level_txt_view = findViewById(R.id.select_level_yr_gp);
        level_grade_view = findViewById(R.id.select_level_yr_grade);
        total_yr_credit = findViewById(R.id.total_level_yr_creditload);
        total_yr_credit.setVisibility(View.INVISIBLE);
        show_the_level = findViewById(R.id.show_level);
        level_txt_view.setVisibility(View.INVISIBLE);
        level_grade_view.setVisibility(View.INVISIBLE);
        show_the_level.setVisibility(View.INVISIBLE);
        CheckSpinner();


        show_the_level.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (spinner_level.getSelectedItem().toString().equals("Year One")) {
                    Intent intent = new Intent(getApplicationContext(), tablayoutyr1.class);
                    startActivity(intent);
                }
                else if (spinner_level.getSelectedItem().toString().equals("Year Two")){
                    Intent intent = new Intent(getApplicationContext(),tablayout_year_2.class);
                    startActivity(intent);
                }
            }
        });


    }

    private void CheckSpinner() {

        spinner_level.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                if (0 == position) {
                    level_txt_view.setVisibility(View.INVISIBLE);
                    level_grade_view.setVisibility(View.INVISIBLE);
                    show_the_level.setVisibility(View.INVISIBLE);
                    total_yr_credit.setVisibility(View.INVISIBLE);

                } else if (1 == position) {

                    show_the_level.setVisibility(View.VISIBLE);
                    total_yr_credit.setVisibility(View.VISIBLE);
                    level_txt_view.setVisibility(View.VISIBLE);
                    level_grade_view.setVisibility(View.VISIBLE);
                    SavedDataYearOne();
                } else if (2 == position) {
                    show_the_level.setVisibility(View.VISIBLE);
                    level_txt_view.setVisibility(View.VISIBLE);
                    total_yr_credit.setVisibility(View.VISIBLE);
                    level_grade_view.setVisibility(View.VISIBLE);
                    SavedDataYearTwo();

                } else if (3 == position) {
                    show_the_level.setVisibility(View.VISIBLE);
                    level_txt_view.setVisibility(View.VISIBLE);
                    level_grade_view.setVisibility(View.VISIBLE);
                } else if (4 == position) {
                    show_the_level.setVisibility(View.VISIBLE);
                    level_txt_view.setVisibility(View.VISIBLE);
                    level_grade_view.setVisibility(View.VISIBLE);
                } else if (5 == position) {
                    show_the_level.setVisibility(View.VISIBLE);
                    level_txt_view.setVisibility(View.VISIBLE);
                    level_grade_view.setVisibility(View.VISIBLE);
                } else if (6 == position) {
                    show_the_level.setVisibility(View.VISIBLE);
                    level_txt_view.setVisibility(View.VISIBLE);
                    level_grade_view.setVisibility(View.VISIBLE);
                } else {
                    level_txt_view.setVisibility(View.INVISIBLE);
                    level_grade_view.setVisibility(View.INVISIBLE);
                    show_the_level.setVisibility(View.INVISIBLE);
                    total_yr_credit.setVisibility(View.INVISIBLE);

                }


            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void SavedDataYearOne() {
        SharedPreferences YearOneCum = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor yearoneCumEdit = YearOneCum.edit();
        SharedPreferences firstsaved = getSharedPreferences(firstsemesteryr1.COURSE_NAME, MODE_PRIVATE);
        SharedPreferences secondsaved = getSharedPreferences(secondsemesteryr1.SECOND_SEMESTER_YEAR1, MODE_PRIVATE);
        int CreditLoadTotalfirst = firstsaved.getInt("ADDSK", 0);
        int CreditLoadTotalSecond = secondsaved.getInt("ADDSK", 0);

        String Total_Spinner1 = firstsaved.getString("TOTAL_SPINNER", "");
        String Total_Spinner2 = secondsaved.getString("TOTAL_SPINNER", "");
        double first_spin = 0.0;
        double total_spinner1;
        double second_spin = 0.0;
        if (Total_Spinner1.isEmpty()) {
        } else {
            first_spin = Double.parseDouble(String.valueOf(Total_Spinner1));

        }
        if (Total_Spinner2.isEmpty()) {
        } else {
            second_spin = Double.parseDouble(String.valueOf(Total_Spinner2));

        }


        Log.d("SECOND_SEMESTER_TOTAL", " " + CreditLoadTotalSecond);
        Log.d("FIRST_SEMESTER_TOTAL", " " + CreditLoadTotalfirst);
        Log.d("SPINNER_TOTAL_FIRST", "" + Total_Spinner1);
        Log.d("SPINNER_TOTAL_SECOND", "" + Total_Spinner2);


        String gp_grade_first = firstsaved.getString("GP", "");
        String gp_grade_second = secondsaved.getString("GP", "");
        if (((first_spin== 0) || (first_spin == 0)) && ((Total_Spinner1.isEmpty()) || (Total_Spinner2.isEmpty()))) {
            level_txt_view.setText("GP: NOT AVAILABLE");
            level_grade_view.setText("GRADE: NOT AVAILABLE");
            total_yr_credit.setText("TOTAL CREDITLOAD: NOT AVAILABLE");

        } else {

            int CredidLoadTotal = CreditLoadTotalfirst + CreditLoadTotalSecond;
            double totalSpin = first_spin + second_spin;
            double finalScore = totalSpin / CredidLoadTotal;
            int Total_Credit_Load = CreditLoadTotalfirst + CreditLoadTotalSecond;
            DecimalFormat gpa_format = new DecimalFormat("#.#");
            String final_gpa = gpa_format.format(finalScore);
            level_txt_view.setText("GP: " + final_gpa);
            total_yr_credit.setText("TOTAL CREDIT LOAD:  " + Total_Credit_Load );
            yearoneCumEdit.putString("GP_GRADE", final_gpa);

            if (finalScore >= 4.5) {
                level_grade_view.setText("GRADE:  FIRST CLASS ");

            } else if ((finalScore >= 3.5) && (finalScore < 4.5)) {
                level_grade_view.setText("GRADE:  SECOND CLASS UPPER ");
            } else if ((finalScore >= 2.5) && (finalScore < 3.5)) {
                level_grade_view.setText("GRADE:  SECOND CLASS LOWER ");
            } else if ((finalScore >= 1.5) && (finalScore < 2.5)) {
                level_grade_view.setText("GRADE:  PASS");
            } else {
                level_grade_view.setText("GRADE:  FAILED");
            }
        }


    }

    private void SavedDataYearTwo() {

        SharedPreferences firstsaved = getSharedPreferences(first_semester_yr2.COURSE_NAME, MODE_PRIVATE);
        SharedPreferences secondsaved = getSharedPreferences(second_semester_yr2.SECOND_SEMESTER_YEAR1, MODE_PRIVATE);
        int CreditLoadTotalfirst = firstsaved.getInt("ADDSK", 0);
        int CreditLoadTotalSecond = secondsaved.getInt("ADDSK", 0);

        String Total_Spinner1 = firstsaved.getString("TOTAL_SPINNER", "");
        String Total_Spinner2 = secondsaved.getString("TOTAL_SPINNER", "");
        double first_spin = 0.0;
        double total_spinner1;
        double second_spin = 0.0;
        if (Total_Spinner1.isEmpty()) {
        } else {
            first_spin = Double.parseDouble(String.valueOf(Total_Spinner1));

        }
        if (Total_Spinner2.isEmpty()) {
        } else {
            second_spin = Double.parseDouble(String.valueOf(Total_Spinner2));

        }


        Log.d("SECOND_SEMESTER_TOTAL", " " + CreditLoadTotalSecond);
        Log.d("FIRST_SEMESTER_TOTAL", " " + CreditLoadTotalfirst);
        Log.d("SPINNER_TOTAL_FIRST", "" + Total_Spinner1);
        Log.d("SPINNER_TOTAL_SECOND", "" + Total_Spinner2);


        String gp_grade_first = firstsaved.getString("GP", "");
        String gp_grade_second = secondsaved.getString("GP", "");
        if (((first_spin == 0) || (second_spin == 0)) && ((Total_Spinner1.isEmpty() ) || (Total_Spinner2.isEmpty())) )  {
            level_txt_view.setText("GP:  NOT AVAILABLE");
            level_grade_view.setText("GRADE:  NOT AVAILABLE");
            total_yr_credit.setText("TOTAL CREDITLOAD:  NOT AVAILABLE");

        } else {

            int CredidLoadTotal = CreditLoadTotalfirst + CreditLoadTotalSecond;
            double totalSpin = first_spin + second_spin;
            double finalScore = totalSpin / CredidLoadTotal;
            int Total_Credit_Load = CreditLoadTotalfirst + CreditLoadTotalSecond;
            DecimalFormat gpa_format = new DecimalFormat("#.#");
            String final_gpa = gpa_format.format(finalScore);
            level_txt_view.setText("GP: " + final_gpa);
            total_yr_credit.setText("TOTAL CREDIT LOAD: " + Total_Credit_Load );

            if (finalScore >= 4.5) {
                level_grade_view.setText("GRADE:  FIRST CLASS ");

            } else if ((finalScore >= 3.5) && (finalScore < 4.5)) {
                level_grade_view.setText("GRADE:  SECOND CLASS UPPER ");
            } else if ((finalScore >= 2.5) && (finalScore < 3.5)) {
                level_grade_view.setText("GRADE:  SECOND CLASS LOWER ");
            } else if ((finalScore >= 1.5) && (finalScore < 2.5)) {
                level_grade_view.setText("GRADE:  PASS");
            } else {
                level_grade_view.setText("GRADE:  FAILED");
            }
        }


    }


}
